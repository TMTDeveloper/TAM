import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DaftarnasabahPage } from './daftarnasabah';

@NgModule({
  declarations: [
    DaftarnasabahPage,
  ],
  imports: [
    IonicPageModule.forChild(DaftarnasabahPage),
  ],
})
export class DaftarnasabahPageModule {}
