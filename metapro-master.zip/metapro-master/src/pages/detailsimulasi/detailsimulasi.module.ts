import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailsimulasiPage } from './detailsimulasi';

@NgModule({
  declarations: [
    DetailsimulasiPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsimulasiPage),
  ],
})
export class DetailsimulasiPageModule {}
