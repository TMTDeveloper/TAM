import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailsimulasikpaPage } from './detailsimulasikpa';

@NgModule({
  declarations: [
    DetailsimulasikpaPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsimulasikpaPage),
  ],
})
export class DetailsimulasikpaPageModule {}
