import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailsimulasikpmPage } from './detailsimulasikpm';

@NgModule({
  declarations: [
    DetailsimulasikpmPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsimulasikpmPage),
  ],
})
export class DetailsimulasikpmPageModule {}
