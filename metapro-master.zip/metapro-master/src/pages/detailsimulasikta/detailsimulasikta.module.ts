import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailsimulasiktaPage } from './detailsimulasikta';

@NgModule({
  declarations: [
    DetailsimulasiktaPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsimulasiktaPage),
  ],
})
export class DetailsimulasiktaPageModule {}
