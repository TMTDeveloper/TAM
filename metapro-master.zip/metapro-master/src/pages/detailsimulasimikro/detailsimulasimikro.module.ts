import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { DetailsimulasimikroPage } from './detailsimulasimikro';

@NgModule({
  declarations: [
    DetailsimulasimikroPage,
  ],
  imports: [
    IonicPageModule.forChild(DetailsimulasimikroPage),
  ],
})
export class DetailsimulasimikroPageModule {}
