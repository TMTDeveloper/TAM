import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KprPage } from './kpr';

@NgModule({
  declarations: [
    KprPage,
  ],
  imports: [
    IonicPageModule.forChild(KprPage),
  ],
})
export class KprPageModule {}
