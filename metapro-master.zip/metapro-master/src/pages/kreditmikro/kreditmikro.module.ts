import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { KreditmikroPage } from './kreditmikro';

@NgModule({
  declarations: [
    KreditmikroPage,
  ],
  imports: [
    IonicPageModule.forChild(KreditmikroPage),
  ],
})
export class KreditmikroPageModule {}
