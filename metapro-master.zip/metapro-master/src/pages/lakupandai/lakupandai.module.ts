import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { LakupandaiPage } from './lakupandai';

@NgModule({
  declarations: [
    LakupandaiPage,
  ],
  imports: [
    IonicPageModule.forChild(LakupandaiPage),
  ],
})
export class LakupandaiPageModule {}
