import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { MetaproPage } from './metapro';

@NgModule({
  declarations: [
    MetaproPage,
  ],
  imports: [
    IonicPageModule.forChild(MetaproPage),
  ],
})
export class MetaproPageModule {}
