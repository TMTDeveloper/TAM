import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaketdataPage } from './paketdata';

@NgModule({
  declarations: [
    PaketdataPage,
  ],
  imports: [
    IonicPageModule.forChild(PaketdataPage),
  ],
})
export class PaketdataPageModule {}
