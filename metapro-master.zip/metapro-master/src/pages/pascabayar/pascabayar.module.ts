import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PascabayarPage } from './pascabayar';

@NgModule({
  declarations: [
    PascabayarPage
  ],
  imports: [
    IonicPageModule.forChild(PascabayarPage),
  ]
})
export class PascabayarPageModule {}
