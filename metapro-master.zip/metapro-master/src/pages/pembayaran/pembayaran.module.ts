import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PembayaranPage } from './pembayaran';

@NgModule({
  declarations: [
    PembayaranPage,
  ],
  imports: [
    IonicPageModule.forChild(PembayaranPage),
  ],
})
export class PembayaranPageModule {}
