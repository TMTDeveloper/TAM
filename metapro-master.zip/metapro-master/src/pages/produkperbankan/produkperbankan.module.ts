import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ProdukperbankanPage } from './produkperbankan';

@NgModule({
  declarations: [
    ProdukperbankanPage,
  ],
  imports: [
    IonicPageModule.forChild(ProdukperbankanPage),
  ],
})
export class ProdukperbankanPageModule {}
