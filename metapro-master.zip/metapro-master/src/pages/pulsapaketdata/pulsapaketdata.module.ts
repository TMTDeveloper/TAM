import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PulsapaketdataPage } from './pulsapaketdata';

@NgModule({
  declarations: [
    PulsapaketdataPage,
  ],
  imports: [
    IonicPageModule.forChild(PulsapaketdataPage),
  ],
})
export class PulsapaketdataPageModule {}
