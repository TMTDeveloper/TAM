import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { SaldomodalPage } from './saldomodal';

@NgModule({
  declarations: [
    SaldomodalPage,
  ],
  imports: [
    IonicPageModule.forChild(SaldomodalPage),
  ],
})
export class SaldomodalPageModule {}
