import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TransfernasabahPage } from './transfernasabah';

@NgModule({
  declarations: [
    TransfernasabahPage,
  ],
  imports: [
    IonicPageModule.forChild(TransfernasabahPage),
  ],
})
export class TransfernasabahPageModule {}
