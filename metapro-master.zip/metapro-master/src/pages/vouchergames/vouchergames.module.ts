import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { VouchergamesPage } from './vouchergames';

@NgModule({
  declarations: [
    VouchergamesPage
  ],
  imports: [
    IonicPageModule.forChild(VouchergamesPage),
  ],

})
export class VouchergamesPageModule {}
